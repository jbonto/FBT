Ionic.Zip.Unity from https://github.com/r2d2rigo/dotnetzip-for-unity
